An example showing two stubs sharing a channel and two servicers sharing a server.

More complete documentation lives at [grpc.io](http://www.grpc.io/docs/tutorials/basic/python.html).
